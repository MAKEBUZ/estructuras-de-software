declare module '*.mp3' {
    const value: string;
    export default value;
  }